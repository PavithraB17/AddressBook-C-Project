#include <stdio.h>
#include <stdio_ext.h>
#include<ctype.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

void listContacts(AddressBook *addressBook) 
{
    if (addressBook->contactCount == 0) {
        printf("\n📂 No contacts saved yet! Start by adding one. 👤\n");
        return;
    }

    int serialno=1;
    printf("----------------------------------------------------------------------------------\n");
    printf("%-10s %-20s %-25s %-40s\n","Sl.No","Name", "Phone", "Email");
    printf("----------------------------------------------------------------------------------\n");

    for (int i = 0; i < addressBook->contactCount; i++) {
        printf("%-10d %-20s %-25s %-40s\n",serialno,
               addressBook->contacts[i].name,
               addressBook->contacts[i].phone,
               addressBook->contacts[i].email);
               serialno++;
               printf("\n");
    }
    printf("----------------------------------------------------------------------------------\n");

}

void initialize(AddressBook *addressBook) {
    addressBook->contactCount = 0;
    //populateAddressBook(addressBook);
    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);

}

void saveAndExit(AddressBook *addressBook) {
    
    if (addressBook->contactCount == 0) {
        printf("⚠️ Nothing to save! No contacts found.\n");
        fflush(stdout);
        return;
    }

    saveContactsToFile(addressBook); // Save contacts to file
        printf("\n💾 Contacts saved successfully! Exiting program... 👋\n");

    printf("\n-------------------------------------THANKYOU-------------------------------------\n\n");
    exit(EXIT_SUCCESS); // Exit the program
}


void createContact(AddressBook *addressBook)
{
    int validemail;int uniqemail;
    int n,flag=0;
    /*do {
        printf("\n➕ How many contacts do you want to create? ");
        scanf("%d", &n);
        if (n > MAX_CONTACTS) {
            printf("❌ Too many! Storage isn’t sufficient.\n");
        }
    } while (n > MAX_CONTACTS);*/

        if (addressBook->contactCount >= MAX_CONTACTS) {
            printf("⚠️ Address book is full! Cannot add more contacts.\n");
            return;
        }

        Contact newContact;

        do {
            printf("\n👤 Enter Name: ");
            scanf(" %[^\n]", newContact.name);

            if (!isValidName(newContact.name)) {
                printf("❌ Invalid name! Only alphabets and spaces allowed.\n");
            }
        } while (!isValidName(newContact.name));  // read full name with spaces
    

        do {
            printf("📞 Enter Phone (10 digits): ");
            getchar();
            scanf(" %s", newContact.phone);

            if(!is10digits(newContact.phone)){
                printf("❌ Invalid! Must be exactly 10 digits.\n");
            }

            else if (!isValidNum(newContact.phone)) {
                printf("❌ Invalid! Only digits are allowed.\n");
            }

            else if(!isUnique(newContact.phone,addressBook)){
                printf("⚠️ This number already exists!\n");
            }
            
        } while (!is10digits(newContact.phone) || !isValidNum(newContact.phone) || !isUnique(newContact.phone,addressBook));

        do {
            printf("📧 Enter Email: ");
            scanf(" %s", newContact.email);

            validemail=isValidEmail(newContact.email);
            uniqemail=isUniqueEmail(newContact.email, addressBook);

            if (!validemail) 
            {
                printf("❌ Invalid email format!\n");
            }
            else if (!uniqemail) printf("⚠️ This email already exists in your contacts.\n");
        } while (!validemail || !uniqemail);



        // Add to address book
        addressBook->contacts[addressBook->contactCount++] = newContact;

        printf("\n✅ Contact added successfully!\n");
        printf("\n");
    }

void searchContact(AddressBook *addressBook,int indexes[]) 
{
    if (addressBook->contactCount == 0) {
        printf("📂 No contacts saved yet! Add some first. 👤\n");
        return;
    }
    Contact search;
     count=0;
     int s_no=1;
    int choice;
    int fs;
    char input[100];
    int c;
    while ((c = getchar()) != '\n' && c != EOF); // clear input buffer

    do {
        
        fs = 0;
        printf("\n🔍 SEARCH MENU\n");
        printf("  1️⃣ Search by Name\n");
        printf("  2️⃣ Search by Phone Number\n");
        printf("  3️⃣ Search by Email\n");
        printf("  4️⃣ Return to Main Menu\n");
        printf("👉 Enter your choice: ");

        fgets(input, sizeof(input), stdin);   // read full line

        if (sscanf(input, "%d", &choice) != 1) {  // parse integer
            printf("\n❌ Invalid Input! Enter a number 1-4.\n");
            fs = 1;
        }
        else if (choice < 1 || choice > 4) {      // check range
            printf("\n⚠️ Invalid choice! Please try again.\n");
            fs = 1;
        }

    } while (fs);

    
    int flag=0;
    switch(choice)
    {
        case 1:
        {
            flag=0;
            printf("\n👤 Enter Name: ");
            getchar();
            scanf(" %[^\n]",search.name);
            for(int i=0;i<addressBook->contactCount;i++)
            {
                
                if(strcasestr(addressBook->contacts[i].name,search.name)!=NULL)
                {
                    if(flag==0)
                    {
                        printf("\n📋 Matching Contacts:\n");
                        printf("%-6s | %-20s | %-15s | %-30s\n", "ID", "Name", "Phone", "Email");
                        printf("-------------------------------------------------------------------------------\n");
                    }
                    flag=1;
                    printf("%-6d | %-20s | %-15s | %-30s\n",
                           s_no, addressBook->contacts[i].name,
                           addressBook->contacts[i].phone,
                           addressBook->contacts[i].email);
                    indexes[count++]=i;
                    s_no++;
                }
            }
            if(!flag)
            {
                printf("\n❌ No contact found with name '%s'.\n", search.name);
                return;
            }
            printf("\n");
            break;
        }
        case 2:
        {
            flag=0;
            printf("\n📞 Enter Phone Number: ");
            //getchar();
            scanf(" %s",search.phone);
            for(int i=0;i<addressBook->contactCount;i++)
            {
                
                if(strcmp(search.phone,addressBook->contacts[i].phone)==0)
                {
                    if(flag==0)
                    {
                        printf("\n📋 Matching Contacts:\n");
                        printf("%-6s | %-20s | %-15s | %-30s\n", "ID", "Name", "Phone", "Email");
                        printf("-------------------------------------------------------------------------------\n");
                    }
                    flag=1;
                    printf("%-6d | %-20s | %-15s | %-30s\n",
                           s_no, addressBook->contacts[i].name,
                           addressBook->contacts[i].phone,
                           addressBook->contacts[i].email);
                    indexes[count++] = i;
                    s_no++; 
            }  
        }
            if(!flag){
                    printf("\n❌ No contact found with phone '%s'.\n", search.phone);
                    return;
                }
                printf("\n");
            break;
        
    }
    case 3:
    {
            flag=0;
            printf("\n📧 Enter Email: ");
            //getchar();
            scanf("%s", search.email);

            for(int i=0; i < addressBook->contactCount; i++)
            {
                
                if(strcmp(search.email, addressBook->contacts[i].email) == 0)
                {
                    if(flag == 0)
                    {
                        printf("\n📋 Matching Contacts:\n");
                        printf("%-6s | %-20s | %-15s | %-30s\n", "ID", "Name", "Phone", "Email");
                        printf("-------------------------------------------------------------------------------\n");
                    }
                    flag = 1;
                    printf("%-6d | %-20s | %-15s | %-30s\n",
                        s_no, addressBook->contacts[i].name,
                        addressBook->contacts[i].phone,
                        addressBook->contacts[i].email);
                    indexes[count++] = i;
                    s_no++;
                }
            }

            if(!flag){
                printf("\n❌ No contact found with email '%s'.\n", search.email);
                return;            
            }
            printf("\n");
            break;
        }

        case 4:
        {
            printf("\n↩️ Returning to Main Menu...\n");
            return;
        }
    }
    
}


void editContact(AddressBook *addressBook,int index[])
{
    if (addressBook->contactCount == 0) {
        printf("📂 No contacts saved! Add some first. 👤\n");
        return;
    }
  
	searchContact(addressBook,index);
    if(count)
    {
        printf("\n");
        int f;//flag value
        int edit_s=1;
        if(count>1)
        {
                char input[100];
                int c;
                while ((c = getchar()) != '\n' && c != EOF);  // flush leftover input

                do {
                    f = 0;
                    printf("👉 Enter the serial number of the contact to Edit: ");
                    fgets(input, sizeof(input), stdin);  // read entire line

                    if (sscanf(input, "%d", &edit_s) != 1) {  // check if integer
                        printf("❌ Invalid Input! Enter valid serial No, Try again.\n");
                        f = 1;
                    }
                    else if (!(edit_s > 0 && edit_s <= count)) {  // check range
                        printf("❌ Invalid serial number! Try again.\n");
                        f = 1;
                    }

                } while (f);

        }

        int option1=0;int f11=0;//flag value
        Contact newContact1;
        char input[100];
        
        
        do{
            __fpurge(stdin);
            f11=0;
            printf("\n⚙️ What do you want to edit?\n");
            printf("  1️⃣ Name\n");
            printf("  2️⃣ Phone Number\n");
            printf("  3️⃣ Email\n");
            printf("  4️⃣ Done Editing\n");
            printf("👉 Enter your choice: ");
            scanf(" %d",&option1);
            
            if(!(option1>=1 && option1<=4))
            {
                printf("⚠️ Invalid choice! Please try again.\n");
                f11=1;
            }
        }while(f11);
        
        switch (option1)
        {
        case 1:
        {
            printf("  1️⃣ Name\n");
            do {
                printf("\n👤 Enter new Name: ");
                scanf(" %[^\n]", newContact1.name);

                if (!isValidName(newContact1.name)) {
                    printf("❌ Invalid name! Only alphabets and spaces allowed.\n");
                }
            } while (!isValidName(newContact1.name)); 
            strcpy(addressBook->contacts[index[edit_s-1]].name,newContact1.name);
            printf("✅ Name updated successfully!\n");
            break;
        }
        
        case 2:
        {
            printf("  2️⃣ Phone Number\n");
            do 
            {
                printf("📞 Enter Phone (10 digits): \n");
                getchar();
                scanf(" %s", newContact1.phone);

                if(!is10digits(newContact1.phone)){
                    printf("❌ Invalid! Must be exactly 10 digits.\n");
                }

                if (!isValidNum(newContact1.phone)) {
                    printf("❌ Invalid! Only digits are allowed.\n");
                }

                if(!isUnique(newContact1.phone,addressBook)){
                    printf("⚠️ This number already exists!\n");
                }
                
            } while (!is10digits(newContact1.phone) || !isValidNum(newContact1.phone) || !isUnique(newContact1.phone,addressBook));
            strcpy(addressBook->contacts[index[edit_s-1]].phone,newContact1.phone);
            printf("\n✅ Phone updated successfully!\n");
            break;
        }

        case 3:
        {
            printf("  3️⃣ Email\n");
            int validemail;int uniqemail;
            do 
            {
                printf("📧 Enter Email: ");
                scanf(" %s", newContact1.email);

                validemail=isValidEmail(newContact1.email);
                uniqemail=isUniqueEmail(newContact1.email, addressBook);

                if (!validemail) {
                    printf("❌ Invalid email format!\n");
                }
                if (!uniqemail) {
                    printf("⚠️ This email already exists in your contacts.\n");
                }

            } while (!validemail || !uniqemail);
            strcpy(addressBook->contacts[index[edit_s-1]].email,newContact1.email);
            printf("✅ Email updated successfully!\n");
            break;

        }
        default:
            printf("  4️⃣ Done Editing\n");
            printf("\n💾 Changes saved. Returning to main menu...\n");
            break;
        }
    }
    else{
        printf("❌ Invalid option! Try again.\n");
    }
}
    

void deleteContact(AddressBook *addressBook,int index[])
{
    printf("\n");
    if (addressBook->contactCount == 0) {
        printf("📂 No contacts saved! Nothing to delete. ❌\n");
        return;
    }
	if((addressBook->contactCount)>0)
    {
      
	  searchContact(addressBook,index);
      if(count)
        {
            int f1;//flag value
            int del_s=1;
            if(count>1)
            {
                char input[100];
                int c;
                while ((c = getchar()) != '\n' && c != EOF);  // flush leftover input

                do {
                    f1 = 0;
                    printf("\n👉 Enter the Serial No of the contact you want to delete: ");
                    fgets(input, sizeof(input), stdin);  // read entire line

                    if (sscanf(input, "%d", &del_s) != 1) {
                        printf("⚠️ Invalid input! Enter a number.\n");
                        f1 = 1;
                    }
                    else if (!(del_s > 0 && del_s <= count)) {
                        printf("⚠️ Invalid Serial No! Please try again.\n");
                        f1 = 1;
                    }

                } while (f1);

            }
            for(int i=(index[(del_s)-1]);i<((addressBook->contactCount)-1);i++)
            {
                strcpy(addressBook->contacts[i].name,addressBook->contacts[i+1].name);
                strcpy(addressBook->contacts[i].phone,addressBook->contacts[i+1].phone);
                strcpy(addressBook->contacts[i].email,addressBook->contacts[i+1].email);
            }
            addressBook->contactCount--;
            //savetofile(addressBook);
            printf("\n✅ Contact deleted successfully!\n");
        }
    }
    else{
        printf("\n❌ No contact found to delete.\n");
    }
}
