#ifndef CONTACT_H
#define CONTACT_H

#define MAX_CONTACTS 100

typedef struct { 
    char name[50];
    char phone[20];
    char email[50];
} Contact;

typedef struct {
    Contact contacts[100];
    int contactCount;
} AddressBook;

extern int indexes[MAX_CONTACTS];
extern int count;

void createContact(AddressBook *addressBook);
void searchContact(AddressBook *addressBook,int index[]);
void editContact(AddressBook *addressBook,int index[]);
void deleteContact(AddressBook *addressBook,int index[]);
void listContacts(AddressBook *addressBook);
void initialize(AddressBook *addressBook);
void saveContactsToFile(AddressBook *AddressBook);
int isValidName(const char *name);
int is10digits(const char*num);
int isValidNum(const char *num);
int isUnique(const char *num, AddressBook* addressBook);
int isValidEmail(const char *email);
int isUniqueEmail(const char *email, AddressBook* addressBook);
void savetofile(AddressBook *addressBook);
void loadContactsFromFile(AddressBook *addressBook);
void saveAndExit(AddressBook *addressBook);

#endif
