#include <stdio.h>
#include<stdio_ext.h>
#include "contact.h"
int indexes[MAX_CONTACTS];
int count=0;
int main() 
{
    int choice=0;
    AddressBook addressBook;
    initialize(&addressBook); // Initialize the address book
    char input1[100];


    do {
        step1:
        printf("\n----------------------------------ADDRESS BOOK-----------------------------------\n");
        printf("\n=================================================================================\n");
        printf("📒  WELCOME TO YOUR DIGITAL ADDRESS BOOK 📒\n");
        printf("=================================================================================\n");
        printf("✨ MENU ✨\n");
        printf("  1️⃣  Create Contact 👤\n");
        printf("  2️⃣  Search Contact 🔍\n");
        printf("  3️⃣  Edit Contact ✏️\n");
        printf("  4️⃣  Delete Contact 🗑️\n");
        printf("  5️⃣  List All Contacts 📋\n");
        printf("  6️⃣  Save & Exit 💾🚪\n");
        printf("---------------------------------------------------------------------------------\n");
        printf("👉 Enter your choice: ");
        __fpurge(stdin);
        scanf(" %d",&choice);
        
        switch (choice) {
            case 1:
                printf("\n🆕 Creating a new contact...\n");
                createContact(&addressBook);
                break;
            case 2:
                printf("\n🔍 To Search a contact Please Press Enter!!!...\n");
                searchContact(&addressBook,indexes);
                break;
            case 3:
                printf("\n✏️ To edit a contact Please press enter!!!...\n");
                editContact(&addressBook,indexes);
                break;
            case 4:
                printf("\n🗑️ Deleting a contact...\n");
                deleteContact(&addressBook,indexes);
                break;
            case 5:
                printf("\n📋 Listing all contacts...\n");          
                listContacts(&addressBook);
                break;
            case 6:
                //printf("\n💾 Saving your contacts and exiting... Goodbye! 👋\n");                
                saveAndExit(&addressBook);
                break;
            default:
                printf("\n⚠️ Invalid choice! Please try again.\n");
        }
    } while(choice != 6);
    
    return 0;
}
