#include <stdio.h>
#include<ctype.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

int isValidName(const char *name) {
    for (int i = 0; name[i] != '\0'; i++) {
        if (!isalpha(name[i]) && name[i] != ' ') {
            return 0; // invalid
        }
    }
    return 1; // valid
}

int is10digits(const char*num)
{
    int len = strlen(num);

    if (len != 10) {
        return 0; // invalid if not 10 digits
    }
    return 1;
}

int isValidNum(const char *num) {

    for (int i = 0; num[i] != '\0'; i++) {
        if (!isdigit(num[i])) {
            return 0; // invalid
        }
    }
    return 1; // valid
}

int isUnique(const char *num, AddressBook* addressBook) {
    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(num, addressBook->contacts[i].phone) == 0) {
            return 0; // not unique (duplicate found)
        }
    }
    return 1; // unique
}

int isValidEmail(const char *email) {
    
    char *at = strchr(email, '@');
    if (!at || at == email) 
    {
        if(!at) printf("⚠️ Invalid email: missing '@' symbol.\n");
        if(at==email) printf("⚠️ Invalid email: requires characters before '@'.\n");
        return 0;// Check if '@' is present
    } 
    
    // Check if it ends with ".com"
    int len = strlen(email);
    

    if(strcmp(email + len - 4, ".com") != 0) {
        const char* dotcom=strstr(email,".com");
        if(dotcom) printf("'⚠️ Invalid email: '.com' must be at the end.\n");
        else printf("⚠️ Invalid email: missing '.com'.\n");
        return 0; // check whether .com present and it is at the end
    }
    
    if (strchr(at + 1, '@')) {
        printf("⚠️ Invalid email: multiple '@' symbols not allowed.\n");
        return 0;
    }

      if(strcmp(at+1,".com")==0)
      {
        printf("⚠️ Invalid email: requires characters between '@' and '.com'.\n");
        return 0;
      }
        

    return 1; // valid
}

int isUniqueEmail(const char *email, AddressBook* addressBook) {
    for (int i = 0; i < addressBook->contactCount; i++) {
        if (strcmp(email, addressBook->contacts[i].email) == 0) {
            return 0; // not unique
        }
    }
    return 1; // unique
}

