#include <stdio.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *fptr1 = fopen("contacts.csv", "w");
    if (fptr1 == NULL) {
        printf("❌ Error opening file for saving!\n");
        return;
    }

    fprintf(fptr1,"%d\n",addressBook->contactCount);

    for (int i = 0; i < addressBook->contactCount; i++) {
        fprintf(fptr1, "%s,%s,%s\n",
                addressBook->contacts[i].name,
                addressBook->contacts[i].phone,
                addressBook->contacts[i].email);
    }

    fclose(fptr1);
}

void loadContactsFromFile(AddressBook *addressBook) 
{
    FILE *fptr2 = fopen("contacts.csv", "r");
    if (fptr2 == NULL) {
        printf("📂 No saved contacts found. Starting with an empty Address Book. 📝\n");
        return;
    }
    int num;

    fscanf(fptr2,"%d\n",&num);
    
    addressBook->contactCount=num;

    for (int i = 0; i < addressBook->contactCount; i++) {
        fscanf(fptr2, "%[^,],%[^,],%[^\n]\n",
                addressBook->contacts[i].name,
                addressBook->contacts[i].phone,
                addressBook->contacts[i].email);
    }

    fclose(fptr2);
}



