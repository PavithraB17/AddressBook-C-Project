#include<stdio.h>
#include "contact.h"
// Dummy contact data
static Contact dummyContacts[] = {
    {"John Doe", "1234567890", "john@example.com\n"},
    {"Alice Smith", "0987654321", "alice@example.com\n"},
    {"Bob Johnson", "1112223333", "bob@company.com\n"},
    {"Carol White", "4445556666", "carol@company.com\n"},
    {"David Brown", "7778889999", "david@example.com\n"},
    {"Eve Davis", "6665554444", "eve@example.com\n"},
    {"Frank Miller", "3334445555", "frank@example.com\n"},
    {"Grace Wilson", "2223334444", "grace@example.com\n"},
    {"Hannah Clark", "5556667777", "hannah@example.com\n"},
    {"Ian Lewis", "8889990000", "ian@example.com\n"}
};

void populateAddressBook(AddressBook* addressBook)
{
    int numDummyContacts = sizeof(dummyContacts) / sizeof(dummyContacts[0]);
    for (int i = 0; i < numDummyContacts && addressBook->contactCount < MAX_CONTACTS; ++i) {
        addressBook->contacts[addressBook->contactCount++] = dummyContacts[i];
    }
    FILE* fptr = fopen("contacts.txt","w");
    if (fptr == NULL) {
        printf("Error: Could not open file \n");
        return;
    }

    for (int i = 0; i < addressBook->contactCount; i++) {
        fprintf(fptr, "%s,%s,%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
    }

    fclose(fptr);


}